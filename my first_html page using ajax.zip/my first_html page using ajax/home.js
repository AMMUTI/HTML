var xhr = new XMLHttpRequest ();
xhr.onload = function() {
  if (xhr.status === 200){
    document.getElementById('home').innerHTML = xhr.responseText;
  }
};
xhr.open('GET', 'b.html', true);
xhr.send(null);
